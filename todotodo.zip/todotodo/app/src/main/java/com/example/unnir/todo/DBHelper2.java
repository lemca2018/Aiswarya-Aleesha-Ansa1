package com.example.unnir.todo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by UNNIR on 4/9/2017.
 */

public class DBHelper2 extends SQLiteOpenHelper {
    private static final String DB_NAME1 = "EDMTDev1";
    private static final int DB_VER1 = 1;
    public static final String DB_TABLE1 = "Task1";
    public static final String DB_COLUM1 = "TaskName1";


    public DBHelper2(Context context) {
        super(context, DB_NAME1, null, DB_VER1);
    }
    @Override
    public void onCreate(SQLiteDatabase db1) {
        String query = String.format("CREATE TABLE %s (ID INTEGER PRIMARY KEY AUTOINCREMENT,%s TEXT NOT NULL);", DB_TABLE1, DB_COLUM1);
        db1.execSQL(query);


    }


    @Override
    public void onUpgrade(SQLiteDatabase db1, int oldVersion, int newVersion) {
        String query = String.format("DELETE TABLE IF EXISTS %s", DB_TABLE1);
        db1.execSQL(query);
        onCreate(db1);

    }
    public  void insertNewTask1(String task){
        SQLiteDatabase db1=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(DB_COLUM1,task);
        db1.insertWithOnConflict(DB_TABLE1,null,values,SQLiteDatabase.CONFLICT_REPLACE);
        db1.close();
    }
    public void deleteTask1(String task){
        SQLiteDatabase db1=this.getWritableDatabase();
        // db.delete(DB_TABLE,DB_COLUM + " - ?",new String[]{task});
        db1.delete(DB_TABLE1, DB_COLUM1 + " = ?", new String[]{ task });//
        db1.close();
    }
    public ArrayList<String> getTaskList(){
        ArrayList<String> taskList=new ArrayList<>();
        SQLiteDatabase db1=this.getReadableDatabase();
        Cursor cursor= db1.query(DB_TABLE1,new String[]{DB_COLUM1},null,null,null,null,null);
        while (cursor.moveToNext()){
            int index=cursor.getColumnIndex(DB_COLUM1);
            taskList.add(cursor.getString(index));

        }
        cursor.close();
        db1.close();
        return taskList;
    }
}
