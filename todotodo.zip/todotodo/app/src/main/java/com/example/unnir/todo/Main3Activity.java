package com.example.unnir.todo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main3Activity extends AppCompatActivity {
    Button shop,home1,studies1,social1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        shop = (Button) findViewById(R.id.shoping);

        shop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main3Activity.this,MainActivity.class);
                Main3Activity.this.startActivity(intent);
            }
        });
        home1= (Button) findViewById(R.id.home);

        home1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main3Activity.this,Main4Activity.class);
                Main3Activity.this.startActivity(intent);
            }
        });
        studies1= (Button) findViewById(R.id.studies);

        studies1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main3Activity.this,studies.class);
                Main3Activity.this.startActivity(intent);
            }
        });
        social1 = (Button) findViewById(R.id.social);

        social1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main3Activity.this,social.class);
                Main3Activity.this.startActivity(intent);
            }
        });
    }
}
